import "./App.css";
import axios from "axios";
import { useEffect, useState } from "react";

function App() {
  const MYSERVER = "http://127.0.0.1:3005/notes/";

  const [notes, setNotes] = useState([]);

  useEffect(() => {
    const get_all = async () => {
      let res = await axios.get(MYSERVER);
      setNotes(res.data);
    };
    get_all();
  }, []);

  return (
    <div className="App">
      hello
      {notes.map((note, i) => (
        <div key={i}>
          {note.title} - {note.content}
        </div>
      ))}
    </div>
  );
}

export default App;

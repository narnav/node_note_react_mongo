import React from "react";

const x = () => {
  return <div>x</div>;
};

export default x;

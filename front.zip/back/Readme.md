# Application files

serverjs - app.py
note.model.js - like model in django/flask/sqlalchemy
note.routes.js -URLS (DJANGO)
note.controller.js - views
database.config.js - data base configuration

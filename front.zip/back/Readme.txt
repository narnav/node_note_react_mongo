//taken from ...
https://www.callicoder.com/node-js-express-mongodb-restful-crud-api-tutorial/
https://github.com/callicoder/node-easy-notes-app/blob/master/server.js

to simply run sample need just 
mpm install
nodemon serve.js 
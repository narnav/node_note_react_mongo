module.exports = {
    url: "mongodb://localhost:27017/"
    //remote -working good
    //url: 'mongodb+srv://pashkelon:Avi123456@cluster0-aeknn.azure.mongodb.net/test?retryWrites=true&w=majority'
}